잘씀 / Jalsseum — Official press kit, 2026-10-13
Website: https://yunseokl.github.io/jalsseum/
English: https://yunseokl.github.io/jalsseum/en.html
Contact: dev@ponu.co.kr
Publisher: Portable Nutrition Co., Ltd. / 주식회사 포터블뉴트리션

잘씀은 개인 기록과 공동 생활비를 나눠 관리하는 가계부입니다.
Jalsseum keeps personal records and shared living costs in separate ledgers.

Status updated 2026-10-20: Available on the South Korean App Store and inside Toss. Android release remains under review.
App Store: https://apps.apple.com/kr/app/id6818830953
Toss: Find 잘씀 in the Toss app and choose 토스로 시작하기.
Scope: Korean/English UI; KRW-based budgets. No automatic bank connection or message-inbox collection.
Price and release countries: Free iPhone download in South Korea. Paid-pass terms are separate. Do not describe worldwide or Google Play availability as confirmed.
The 30-second video is silent, with Korean text. Screenshots contain illustrative data.

Usage: You may use these materials to cover Jalsseum. Do not misrepresent the app, release status, endorsements or partnerships. Brand rights remain with the publisher.
