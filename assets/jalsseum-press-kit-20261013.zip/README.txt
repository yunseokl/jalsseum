잘씀 / Jalsseum — Official press kit, 2026-10-13
Website: https://yunseokl.github.io/jalsseum/
English: https://yunseokl.github.io/jalsseum/en.html
Contact: dev@ponu.co.kr
Publisher: Portable Nutrition Co., Ltd. / 주식회사 포터블뉴트리션

잘씀은 개인 기록과 공동 생활비를 나눠 관리하는 가계부입니다.
Jalsseum keeps personal records and shared living costs in separate ledgers.

Status: Prelaunch, internal testing. General downloads are not open.
Scope: Korean/English UI; KRW-based budgets. No automatic bank connection or message-inbox collection.
Price and release countries: Not yet announced. Do not describe it as free to install or available worldwide.
The 30-second video is silent, with Korean text. Screenshots contain illustrative data.

Usage: You may use these materials to cover Jalsseum. Do not misrepresent the app, release status, endorsements or partnerships. Brand rights remain with the publisher.
